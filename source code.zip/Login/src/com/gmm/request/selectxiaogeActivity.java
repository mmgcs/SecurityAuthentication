package com.gmm.request;

import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONObject;

import com.example.login.CreateDataBase;
import com.example.login.R;

import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class selectxiaogeActivity extends Activity implements OnClickListener{
	private ListView list;
	private SimpleAdapter mSimpleAdapter;	
	private ArrayList<HashMap<String, Object>> listItem = new ArrayList<HashMap<String,Object>>();
	private HashMap<String,Object> Map2 =new HashMap<String,Object>();
	private TextView back,add;
	private String shou_name,shou_phone,shou_addr,shou_addr_info,
	ji_name,ji_phone,ji_addr,ji_addr_info,
	personid,info;
	private CreateDataBase dbhelper;
	private SQLiteDatabase db;
	private Handler handler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			String result = msg.obj.toString();
			Log.d("result", result);
			JSONArray alist = new JSONArray();
			try {
				JSONObject json = new JSONObject(result);
				alist = json.getJSONArray("result");
				for (int i = 0; i <alist.length(); i++) {
					Log.d("df", alist.getString(i));
					JSONObject json_item =new JSONObject(alist.getString(i));
					String name = json_item.getString("name");
					String company = json_item.getString("company");
					String phone = json_item.getString("phone");
					HashMap<String, Object> map = new HashMap<String, Object>();
					map.put("logo", Map2.get(company));
					map.put("name", name);
					map.put("phone",phone);
					map.put("company", company);
					
					listItem.add(map);
					
				}
				mSimpleAdapter = new SimpleAdapter(selectxiaogeActivity.this, listItem, R.layout.item_xiaoge_info,
						new String[]{"logo", "phone","name","company"},new int[]{R.id.xiaoge_info_img,R.id.xiaoge_info_phone,R.id.xiaoge_info_name,R.id.xiaoge_info_company});
				list.setAdapter(mSimpleAdapter);
				
			} catch (Exception e) {
				// TODO: handle exception
			}
		};
	};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.selectxiaoge);
		list = (ListView) findViewById(R.id.selectxiaoge_list);
		dbhelper = new CreateDataBase(this, "triple.db", null, 1);
		db = dbhelper.getWritableDatabase();
		initMap2();
		initxiaoge();
		Intent intent = getIntent();
		shou_name = intent.getStringExtra("shou_name");
		shou_phone = intent.getStringExtra("shou_phone");
		shou_addr = intent.getStringExtra("shou_addr");
		shou_addr_info = intent.getStringExtra("shou_addr_info");
		ji_name = intent.getStringExtra("ji_name");
		ji_phone = intent.getStringExtra("ji_phone");
		ji_addr = intent.getStringExtra("ji_addr");
		ji_addr_info = intent.getStringExtra("ji_addr_info");
		info = intent.getStringExtra("info");
		personid = intent.getStringExtra("personid");
		
		mSimpleAdapter = new SimpleAdapter(selectxiaogeActivity.this, listItem, R.layout.item_xiaoge_info,
				new String[]{"company", "phone","name"},new int[]{R.id.xiaoge_info_img,R.id.xiaoge_info_phone,R.id.xiaoge_info_name});
		list.setAdapter(mSimpleAdapter);
		list.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				HashMap<String, Object> item_map =listItem.get(position);
				final String phone =item_map.get("phone").toString();
				final String company =item_map.get("company").toString();
				new Thread( new Runnable() {
					public void run() {
						onlineRequest(phone,company);
					}
				}).start();
				Toast.makeText(selectxiaogeActivity.this, "��ԤԼ", Toast.LENGTH_SHORT).show();
				finish();
				
				
			}

			private void onlineRequest(String expresser,String company) {
				Request request =new Request();
				String url_str = request.root_url+"addorder";
				String parameter ="ji_phone="+ji_phone+"&ji_name="+ji_name+"&ji_addr="+ji_addr+"&ji_addr_info="+ji_addr_info
						+"&shou_name="+shou_name+"&shou_phone="+shou_phone+"&shou_addr="+shou_addr+"&shou_addr_info="+shou_addr_info
						+"&info="+info+"&personid="+personid+"&expresser="+expresser+"&company="+company;
				Log.d("parameter", parameter);
				String result = request.initSSLALL(url_str, parameter);
				
			}
		});
		
	}
	private void initxiaoge() {
		new Thread(new Runnable() {
			public void run() {
				Request request = new Request();
				String url_str = request.root_url+"myxiaoge";
				personTest pt = new personTest(db);
				String phone = pt.getphone();
				String parameter = "&phone="+phone;
				String result = request.initSSLALL(url_str, parameter);
				Message msg = new Message();
				msg.obj =result;
				handler.sendMessage(msg);
			}
		}).start();
		
	}
	private void initMap2() {
		Map2.put("shunfeng",R.drawable.shunfeng);
		Map2.put("zhongtong",R.drawable.zhongtong);
		Map2.put("shentong",R.drawable.shentong);
		Map2.put("yuantong",R.drawable.yuantong);
		Map2.put("yunda",R.drawable.yunda);
		Map2.put("huitongkuaidi",R.drawable.yunda);
		Map2.put("ems",R.drawable.ems);
		Map2.put("tiantian",R.drawable.tiantian);
		Map2.put("quanfengkuaidi",R.drawable.quanfeng);
	}
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.myxiaoge_add:
			
			break;
		case R.id.myxiaoge_back:
			finish();
			break;

		default:
			break;
		}
		
	}
	
}
