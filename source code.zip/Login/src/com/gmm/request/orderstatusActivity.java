package com.gmm.request;

import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONObject;

import com.example.login.CreateDataBase;
import com.example.login.R;

import android.app.Activity;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Window;
import android.widget.ListView;
import android.widget.SimpleAdapter;

public class orderstatusActivity extends Activity{
	private ListView list;
	private SimpleAdapter mSimpleAdapter;	
	private ArrayList<HashMap<String, Object>> listItem = new ArrayList<HashMap<String,Object>>();
	private CreateDataBase dbhelper;
	private SQLiteDatabase db;
	private HashMap<String,Object> Map2 =new HashMap<String,Object>();
	private Handler handler = new Handler(){
		public void handleMessage(Message msg) {
			String result = msg.obj.toString();
			JSONArray alist = new JSONArray();
			try {
				JSONObject json = new JSONObject(result);
				alist = json.getJSONArray("result");
				for (int i = 0; i <alist.length(); i++) {
					Log.d("df", alist.getString(i));
					JSONObject json_item =new JSONObject(alist.getString(i));
					String info = json_item.getString("info");
					String company = json_item.getString("company");
					String expresser = json_item.getString("expresser");
					String flag = json_item.getString("flag");
					String id = json_item.getString("id");
					HashMap<String, Object> map = new HashMap<String, Object>();
					map.put("logo", Map2.get(company));
					map.put("info", info);
					map.put("expresser",expresser);
					map.put("flag",flag);
					map.put("id",id);
					listItem.add(map);
					
				}
				mSimpleAdapter = new SimpleAdapter(orderstatusActivity.this, listItem, R.layout.item_order_status,
						new String[]{"logo", "info","expresser","flag","id"},new int[]{R.id.order_status_img,R.id.order_status_info,R.id.order_status_expresser,R.id.order_status_status,R.id.order_status_id});
				list.setAdapter(mSimpleAdapter);
				
			} catch (Exception e) {
				// TODO: handle exception
			}
		};
	};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.orderstatus);
		Log.d("nihao", "df");
		list = (ListView) findViewById(R.id.order_status_list);
		dbhelper = new CreateDataBase(this, "triple.db", null, 1);
		db = dbhelper.getWritableDatabase();
		initMap2();
		initOrderStatus();
	}
	
	
	private void initMap2() {
		Map2.put("shunfeng",R.drawable.shunfeng);
		Map2.put("zhongtong",R.drawable.zhongtong);
		Map2.put("shentong",R.drawable.shentong);
		Map2.put("yuantong",R.drawable.yuantong);
		Map2.put("yunda",R.drawable.yunda);
		Map2.put("huitongkuaidi",R.drawable.yunda);
		Map2.put("ems",R.drawable.ems);
		Map2.put("tiantian",R.drawable.tiantian);
		Map2.put("quanfengkuaidi",R.drawable.quanfeng);
	}


	private void initOrderStatus() {
		new Thread(new Runnable() {
			public void run() {
				personTest pt = new personTest(db);
				String phone = pt.getphone();
				Request request = new Request();
				String url_str = request.root_url+"orderstatus";
				String parameter = "phone="+phone;
				Log.d("gmm", parameter);
				String result = request.initSSLALL(url_str, parameter);
				Log.d("gmm", result);
				Message msg = new Message();
				msg.obj = result;
				handler.sendMessage(msg);
				
			}
		}).start();
		
	}
	
}
