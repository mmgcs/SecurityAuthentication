package com.gmm.request;

import com.example.ecdsa.des;
import com.example.ecdsa.ecdsa;
import com.example.login.CreateDataBase;
import com.wujay.fund.widget.GestureContentView;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public class personTest {
	private String phone;
	private Cursor cursor;
	private SQLiteDatabase db;
	public personTest(SQLiteDatabase db) {
		this.db = db;
		cursor = db.rawQuery("select user_phone from users where user_flag=1", null);
		if (cursor.moveToFirst()) {
			this.phone = cursor.getString(0);
		}
		
		
		// TODO Auto-generated constructor stub
	}
	public String getphone(){
		
		return this.phone;
	}
	public String getSign(String src,String des_key) throws Exception{
		cursor = db.rawQuery("select user_encry_prikey from users where user_phone=?", new String[]{phone});
		if (cursor.moveToFirst()) {
			String encry_prikey = cursor.getString(0);
			Log.d("sdfg", encry_prikey);
		    String prikey;
		    prikey = new String(des.decrypt(des.decryptBASE64(encry_prikey),des_key));
		    ecdsa Ecdsa = new ecdsa();
		    Ecdsa.jdkECDSA();
		    return Ecdsa.Sign(src, prikey);
			
		}
		return "error";
	}
	public String getPub(){
		cursor = db.rawQuery("select user_pubkey from users where user_phone=?", new String[]{phone});
		if (cursor.moveToFirst()) {
			return cursor.getString(0);
		    
			
		}
		return "error";
	}
	public String getPub_sign(){
		cursor = db.rawQuery("select user_pubkey_sign from users where user_phone=?", new String[]{phone});
		if (cursor.moveToFirst()) {
			String pubkey_sign = cursor.getString(0);
		    return pubkey_sign;
		}
		return "error";
	}
	public boolean getCheck(String sign,String pub,String src){
		ecdsa Ecdsa = new ecdsa();
		Ecdsa.jdkECDSA();
		return ecdsa.SignCheck(src, sign, pub);
		
	}
	public String getName(){
		cursor = db.rawQuery("select user_name from users where user_phone=?", new String[]{phone});
		if (cursor.moveToFirst()) {
			return cursor.getString(0);
		}
		return "error";
		
	}
	public String getCity(){
		cursor = db.rawQuery("select user_address from users where user_phone=?", new String[]{phone});
		if (cursor.moveToFirst()) {
			return cursor.getString(0);
		}
		return "error";
	}

}
