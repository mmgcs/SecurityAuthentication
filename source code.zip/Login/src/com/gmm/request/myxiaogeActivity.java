package com.gmm.request;

import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONObject;

import com.example.login.CreateDataBase;
import com.example.login.R;
import com.example.login.expressStatusActivity;

import android.app.Activity;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

public class myxiaogeActivity extends Activity implements OnClickListener{
	private ListView list;
	private SimpleAdapter mSimpleAdapter;	
	private ArrayList<HashMap<String, Object>> listItem = new ArrayList<HashMap<String,Object>>();
	private HashMap<String,Object> Map2 =new HashMap<String,Object>();
	private TextView back,add;
	private CreateDataBase dbhelper;
	private SQLiteDatabase db;
	private Handler handler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			String result = msg.obj.toString();
			Log.d("result", result);
			JSONArray alist = new JSONArray();
			try {
				JSONObject json = new JSONObject(result);
				alist = json.getJSONArray("result");
				for (int i = 0; i <alist.length(); i++) {
					Log.d("df", alist.getString(i));
					JSONObject json_item =new JSONObject(alist.getString(i));
					String name = json_item.getString("name");
					String company = json_item.getString("company");
					String phone = json_item.getString("phone");
					HashMap<String, Object> map = new HashMap<String, Object>();
					map.put("company", Map2.get(company));
					map.put("name", name);
					map.put("phone",phone);
					
					listItem.add(map);
					
				}
				mSimpleAdapter = new SimpleAdapter(myxiaogeActivity.this, listItem, R.layout.item_xiaoge_info,
						new String[]{"company", "phone","name"},new int[]{R.id.xiaoge_info_img,R.id.xiaoge_info_phone,R.id.xiaoge_info_name});
				list.setAdapter(mSimpleAdapter);
				
			} catch (Exception e) {
				// TODO: handle exception
			}
		};
	};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.myxiaoge);
		list = (ListView) findViewById(R.id.myxiaoge_list);
		back = (TextView) findViewById(R.id.myxiaoge_back);
		add = (TextView) findViewById(R.id.myxiaoge_add);
		back.setOnClickListener(this);
		add.setOnClickListener(this);
		dbhelper = new CreateDataBase(this, "triple.db", null, 1);
		db = dbhelper.getWritableDatabase();
		initMap2();
		initxiaoge();
			
	}
	private void initxiaoge() {
		new Thread(new Runnable() {
			public void run() {
				Request request = new Request();
				String url_str = request.root_url+"myxiaoge";
				personTest pt = new personTest(db);
				String phone = pt.getphone();
				String parameter = "&phone="+phone;
				String result = request.initSSLALL(url_str, parameter);
				Message msg = new Message();
				msg.obj =result;
				handler.sendMessage(msg);
			}
		}).start();
//		HashMap<String, Object> map = new HashMap<String, Object>();
//		map.put("company",Map2.get("shunfeng"));
//		map.put("phone","13159876723");
//		map.put("name","gmm");
//		listItem.add(map);
//		HashMap<String, Object> map1 = new HashMap<String, Object>();
//		map1.put("company",Map2.get("zhongtong"));
//		map1.put("phone","13159876345");
//		map1.put("name","������");
//		listItem.add(map1);
		
	}
	private void initMap2() {
		Map2.put("shunfeng",R.drawable.shunfeng);
		Map2.put("zhongtong",R.drawable.zhongtong);
		Map2.put("shentong",R.drawable.shentong);
		Map2.put("yuantong",R.drawable.yuantong);
		Map2.put("yunda",R.drawable.yunda);
		Map2.put("huitongkuaidi",R.drawable.yunda);
		Map2.put("ems",R.drawable.ems);
		Map2.put("tiantian",R.drawable.tiantian);
		Map2.put("quanfengkuaidi",R.drawable.quanfeng);
	}
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.myxiaoge_add:
			
			break;
		case R.id.myxiaoge_back:
			finish();
			break;

		default:
			break;
		}
		
	}
}
