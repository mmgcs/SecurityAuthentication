package com.gmm.request;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLConnection;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.http.client.utils.URLEncodedUtils;

import android.os.Message;
import android.util.Log;

public class Request {
	private  StringBuffer result = null;
	private  String post_str=null;
	public String root_url="http://gmm985.jsp.jspee.com.cn/";
	public  String initSSLALL(String url_str,String parameter) {
	    try {
	        URL url = new URL(url_str);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.setDoOutput(false);
            connection.setRequestMethod("POST");
            connection.connect();
            DataOutputStream out = new DataOutputStream(connection.getOutputStream());
            out.write(parameter.getBytes());
            InputStream in = connection.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            String line = "";
            result = new StringBuffer();
            
            while ((line = reader.readLine()) != null) {
                result.append(line);
            }
            in.close();
            Log.d("gmm", result.toString());
            return result.toString();
        } catch (Exception e) {
            Log.d("gmm","errpr");
            return "error";
            
        }
		
		
		
	
//	public class TrustAllManager implements X509TrustManager {
//
//		@Override
//		public void checkClientTrusted(X509Certificate[] arg0, String arg1)
//				throws CertificateException {
//			// TODO Auto-generated method stub
//
//		}
//
//		@Override
//		public void checkServerTrusted(X509Certificate[] arg0, String arg1)
//				throws CertificateException {
//			// TODO Auto-generated method stub
//
//		}
//
//		@Override
//		public X509Certificate[] getAcceptedIssuers() {
//			// TODO Auto-generated method stub
//			return null;
		
	}
}
