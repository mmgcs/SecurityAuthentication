package com.ericssonlabs;

import com.google.zxing.WriterException;
import com.zxing.encoding.EncodingHandler;
import com.example.login.*;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.TextureView;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class erweimaActivity extends Activity {
    /** Called when the activity is first created. */
	private String contentString;
	private ImageView qrImgImageView;	
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.saomaji);
        Log.d("erweima", "1");
        Intent intent = getIntent();        
        contentString = intent.getStringExtra("password");
        Log.d("erweima", "2");
        qrImgImageView = (ImageView) this.findViewById(R.id.saomaji_image); 
       // Log.d("erweima", "3");
		if (!contentString.equals("")){		
			Bitmap qrCodeBitmap;
			try {
				qrCodeBitmap = EncodingHandler.createQRCode(contentString, 400);
				qrImgImageView.setImageBitmap(qrCodeBitmap);
			} catch (WriterException e) {
				// TODO Auto-generated catch block
				Log.d("erweima", "4");
				e.printStackTrace();
			}
		}else{
			Toast.makeText(erweimaActivity.this, "Text can not be empty", Toast.LENGTH_SHORT).show();
		}
    }
			

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == RESULT_OK) {
			Bundle bundle = data.getExtras();
			String scanResult = bundle.getString("result");
		}
	}
}