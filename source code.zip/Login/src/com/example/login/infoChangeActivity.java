package com.example.login;

import com.gmm.request.Request;

import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class infoChangeActivity extends Activity implements OnClickListener{
	private TextView back;
	private TextView title,submit;
	private EditText info;
	private String title_str,info_str,flag,phone;
	private CreateDataBase dbhelper;
	private SQLiteDatabase db;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.infochange);
		dbhelper = new CreateDataBase(this,"triple.db", null, 1);
		db = dbhelper.getWritableDatabase();
		back = (TextView) findViewById(R.id.changeinfo_back);
		title = (TextView) findViewById(R.id.changeinfo_title);
		submit = (TextView) findViewById(R.id.changeinfo_submit);
		info = (EditText) findViewById(R.id.changeinfo_info);
		Intent intent = getIntent();
		title_str = intent.getStringExtra("title");
		info_str = intent.getStringExtra("info");
		flag = intent.getStringExtra("flag");
		phone = intent.getStringExtra("phone");
		title.setText(title_str);
		info.setText(info_str);
		back.setOnClickListener(this);
		submit.setOnClickListener(this);
		
	}
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.changeinfo_back:
			finish();
			break;
		case R.id.changeinfo_submit:
			updateSQL();
			//updateRequest();
			Intent inte_submit = new Intent(infoChangeActivity.this,PersonActivity.class);
			startActivity(inte_submit);
			finish();
			
			break;

		default:
			break;
		}
		
	}
	private void updateSQL() {
		
		if (flag.equals("0")) {
			db.execSQL("update users set user_name=? where user_phone=?",new String[]{info.getText().toString(),phone});
		}else if (flag.equals("1")) {
			db.execSQL("update users set user_email=? where user_phone=?",new String[]{info.getText().toString(),phone});
			
		}
		new Thread(new Runnable() {
			public void run() {
				Request request = new Request();
				String url_str = request.root_url+"changeinfo";
				String parameter="phone="+phone+"&flag="+flag+"&info="+info.getText().toString();
				request.initSSLALL(url_str, parameter);
			}
		}).start();
		
		
	}
	
	

}
