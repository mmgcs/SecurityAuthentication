package com.example.login;

import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.gmm.request.Request;
import com.gmm.request.personTest;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

public class expressStatusActivity extends Activity implements OnClickListener
{
	protected static final int SHOW_RESPONSE = 0;
	private TextView status0,status1,status2;
	private CreateDataBase dbhelper;
	private SQLiteDatabase db;
	private Cursor cursor;
	private ImageView back;
	private ListView list;
	private View line0,line1,line2;
	private String flag;
	private personTest pt;
	private SimpleAdapter mSimpleAdapter;	
	private ArrayList<HashMap<String, Object>> listItem = new ArrayList<HashMap<String,Object>>();
	private HashMap<String, String> Map1 =new HashMap<String,String>();
	private HashMap<String, Object> Map2 = new HashMap<String,Object>();
	private Handler handler = new Handler(){
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case 1:
				String result = msg.obj.toString();
				JSONArray alist = new JSONArray();
				try {
					JSONObject json_obj = new JSONObject(result);
					alist = json_obj.getJSONArray("result");
					listItem.clear();
					for (int i = 0; i <alist.length(); i++) {
						Log.d("df", alist.getString(i));
						JSONObject json_item =new JSONObject(alist.getString(i));
						String id = json_item.getString("id");
						String company = json_item.getString("company");
						HashMap<String, Object> map = new HashMap<String, Object>();
						map.put("id", id);
						map.put("company1", company);
						map.put("company", Map1.get(company));
						map.put("logo", Map2.get(company));
						listItem.add(map);
						
					}
					mSimpleAdapter = new SimpleAdapter(expressStatusActivity.this, listItem, R.layout.item_express_status,
							new String[]{"id", "company","logo","company1"},new int[]{R.id.express_status_id,R.id.express_status_company,R.id.express_status_logo,R.id.express_status_company1});
					list.setAdapter(mSimpleAdapter);	
					
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				break;

			default:
				break;
			}
		};
	};
		
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		initMap1();
		initMap2();
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);			
		setContentView(R.layout.express_status);
		status0 = (TextView) findViewById(R.id.express_status_0);
		status1 = (TextView) findViewById(R.id.express_status_1);
		status2 = (TextView) findViewById(R.id.express_status_2);
		back = (ImageView) findViewById(R.id.express_status_back);
		status0.setOnClickListener(this);
		status1.setOnClickListener(this);
		status2.setOnClickListener(this);
		back.setOnClickListener(this);
		line0 =findViewById(R.id.express_status_line2);
		line1 =findViewById(R.id.express_status_line4);
		line2 =findViewById(R.id.express_status_line3);
		dbhelper = new CreateDataBase(this, "triple.db", null, 1);
		db = dbhelper.getWritableDatabase();
		pt = new personTest(db);
		list = (ListView) findViewById(R.id.express_status_list);
		
		Intent intent = getIntent();
		flag = intent.getStringExtra("flag");
		switch (flag) {
		case "0":
			line0.setVisibility(View.VISIBLE);
			line1.setVisibility(View.GONE);
			line2.setVisibility(View.GONE);
			
			break;
		case "1":
			line1.setVisibility(View.VISIBLE);
			line0.setVisibility(View.GONE);
			line2.setVisibility(View.GONE);
			
			break;
		case "2":
			line2.setVisibility(View.VISIBLE);
			line0.setVisibility(View.GONE);
			line1.setVisibility(View.GONE);
			break;

		default:
			break;
		}
		query1(flag);
		list.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				HashMap<String, Object> map = listItem.get(position);
				String danhao_id = map.get("id").toString();
				String danhao_company = map.get("company1").toString();
				Log.d("id0", danhao_id);
				Intent inte_showexpress = new Intent("android.intent.action.SHOWEXPRESS" );
				inte_showexpress.putExtra("company", danhao_company);
				inte_showexpress.putExtra("id", danhao_id);
				inte_showexpress.putExtra("status", flag);
				startActivity(inte_showexpress);
				
			}
			
		});
	}
	private void initMap2() {
		Map2.put("shunfeng",R.drawable.shunfeng);
		Map2.put("zhongtong",R.drawable.zhongtong);
		Map2.put("shentong",R.drawable.shentong);
		Map2.put("yuantong",R.drawable.yuantong);
		Map2.put("yunda",R.drawable.yunda);
		Map2.put("huitongkuaidi",R.drawable.yunda);
		Map2.put("ems",R.drawable.ems);
		Map2.put("tiantian",R.drawable.tiantian);
		Map2.put("quanfengkuaidi",R.drawable.quanfeng);
		
	}
	private void initMap1() {
		Map1.put("shunfeng", "˳������");
		Map1.put("zhongtong", "��ͨ���");
		Map1.put("shentong", "��ͨ���");
		Map1.put("yuantong", "Բͨ���");
		Map1.put("yunda", "�ϴ���");
		Map1.put("huitongkuaidi", "������ͨ");
		Map1.put("ems", "EMS");
		Map1.put("tiantian", "������");
		Map1.put("quanfengkuaidi", "ȫ����");
	}
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.express_status_0:
			flag = "0";
			line0.setVisibility(View.VISIBLE);
			line1.setVisibility(View.GONE);
			line2.setVisibility(View.GONE);
			//query(flag);
			query1(flag);
			break;
		case R.id.express_status_1:
			flag = "1";
			line1.setVisibility(View.VISIBLE);
			line0.setVisibility(View.GONE);
			line2.setVisibility(View.GONE);
			query1(flag);
			break;
		case R.id.express_status_2:
			flag = "2";
			line2.setVisibility(View.VISIBLE);
			line1.setVisibility(View.GONE);
			line0.setVisibility(View.GONE);
			query1(flag);
			break;
		case R.id.express_status_back:
			finish();
			break;
		default:
			break;
		}
		
		
	}
	private void query1(final String flag2) {
		new Thread(new Runnable() {
			public void run() {
				Request request = new Request();
				String url_str = request.root_url+"express_status";
				String parameter ="status="+flag2+"&phone="+pt.getphone();
				String result = request.initSSLALL(url_str, parameter);
				Log.d("query2", result);
				Message msg = new Message();
				msg.what = 1;
				msg.obj = result;
				handler.sendMessage(msg);
				
			}
		}).start();
		
	}
//	private void query(String status) {
//		listItem.clear();
//		Log.d("status", "2");
//		cursor = db.rawQuery("select ex_id,ex_company from express where ex_status=?",new String[]{status});
//		Log.d("status", "3");
//		if(cursor.moveToFirst()){
//99
//	do {
//				HashMap<String, Object> map = new HashMap<String, Object>();
//				map.put("id", cursor.getString(0));
//				String company = cursor.getString(1);
//				map.put("company1", company);
//				map.put("company", Map1.get(company));
//				map.put("logo", Map2.get(company));
//				listItem.add(map);
//				Log.d("status", "6");
//			} while (cursor.moveToNext());
//		}
//		Log.d("status", "1");
//		mSimpleAdapter = new SimpleAdapter(expressStatusActivity.this, listItem, R.layout.item_express_status,
//				new String[]{"id", "company","logo","company1"},new int[]{R.id.express_status_id,R.id.express_status_company,R.id.express_status_logo,R.id.express_status_company1});
//		list.setAdapter(mSimpleAdapter);		
//	}
	

}
