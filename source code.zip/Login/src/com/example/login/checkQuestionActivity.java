package com.example.login;

import org.json.JSONObject;

import com.gmm.request.Request;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.telephony.TelephonyManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class checkQuestionActivity extends Activity{
	private EditText q,a;
	private Button submit;
	private String phone;
	private Handler handler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			String result = msg.obj.toString();
			try {
				JSONObject json = new JSONObject(result);
				String status = json.getString("status");
				if (status.equals("1")) {
					Intent inte_setpass = new Intent(checkQuestionActivity.this,setPassActivity.class);
					inte_setpass.putExtra("phone",phone);
					startActivity(inte_setpass);
					finish();
				}else {
					Toast.makeText(checkQuestionActivity.this, "��֤ʧ��", Toast.LENGTH_SHORT).show();
				}
				
			} catch (Exception e) {
				// TODO: handle exception
			}
			
		};
	};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.question_check);
		q = (EditText) findViewById(R.id.question_check_question);
		a =(EditText) findViewById(R.id.question_check_answer);
		submit =(Button) findViewById(R.id.question_check_button);
		Intent intent =getIntent();
		phone =intent.getStringExtra("phone");
		String question = intent.getStringExtra("question");
		q.setText(question);
		submit.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				new Thread(new Runnable() {
					public void run() {
						Request request = new Request();
						String url_str = request.root_url+"questioncheck";
						TelephonyManager mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
						String imei = mTelephonyMgr.getDeviceId();
						String parameter = "phone="+phone+"&answer="+a.getText().toString()+"&imei="+imei;
						String result = request.initSSLALL(url_str, parameter);	
						Message msg = new Message();
						msg.obj = result;
						handler.sendMessage(msg);
					}
				}).start();
				
			}
		});
		
		
	}

}
