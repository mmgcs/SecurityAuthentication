package com.example.login;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import com.example.ecdsa.Coder;
import com.gmm.request.Request;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class login_firstActivity2 extends Activity{
	private EditText email,answer;
	private Spinner question;
	private Button submit;
	private String phone,password2;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.login_frist_email);
		Intent intent = getIntent();
		password2 = intent.getStringExtra("password2");
		phone = intent.getStringExtra("phone");
		email = (EditText) findViewById(R.id.login_first_email_mail);
		answer = (EditText) findViewById(R.id.login_first_email_answer);
		question = (Spinner) findViewById(R.id.login_first_email_question);
		submit = (Button) findViewById(R.id.login_first_email_submit);
		submit.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				loginfirstRequest();
				
				
				
			}

			private void loginfirstRequest() {
				new Thread(new  Runnable() {
					public void run() {
						Request request = new Request();
						String url_str = request.root_url+"loginfirst";
						String parameter ="phone="+phone+"&email="+email.getText().toString()+"&pass2="+password2+"&question="+question.getSelectedItem().toString()
								+"&answer="+answer.getText().toString();
						Log.d("g", parameter);
						request.initSSLALL(url_str, parameter);
						
						
					}
				}).start();
				Intent inte_person = new Intent(login_firstActivity2.this,PersonActivity.class);
				startActivity(inte_person);
				finish();
				
			}
		});
		
		
		
	}

}
