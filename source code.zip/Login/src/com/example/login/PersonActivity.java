package com.example.login;




import com.gmm.request.Request;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;


public class PersonActivity extends Activity implements OnClickListener{
	private TextView login,pass1,pass2;
	private TextView text_login,text_name,text_phone,text_email,text_address;
	private String name,phone,email,address;
	private Button logout;
	private CreateDataBase dbhelper;
	private SQLiteDatabase db;
	private Cursor cursor;
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.person);
		dbhelper = new CreateDataBase(this, "triple.db", null, 1);
		text_login = (TextView) findViewById(R.id.person_text_login);
		text_name = (TextView) findViewById(R.id.person_text_name);
		text_phone = (TextView) findViewById(R.id.person_phone);
		text_address = (TextView) findViewById(R.id.person_text_address);
		text_email = (TextView) findViewById(R.id.person_text_email);
		logout = (Button) findViewById(R.id.person_logout);
		login = (TextView) findViewById(R.id.person_login);
		pass1= (TextView) findViewById(R.id.person_pass1);
		pass2= (TextView) findViewById(R.id.person_pass2);
		pass1.setOnClickListener(this);
		pass2.setOnClickListener(this);
		login.setOnClickListener(this);
		logout.setOnClickListener(this);
		text_name.setOnClickListener(this);
		text_address.setOnClickListener(this);
		text_email.setOnClickListener(this);
		initPerson();
		
		
	}
	
		
	
	private void initPerson() {
		Log.d("person", "1");
		db = dbhelper.getWritableDatabase();
		cursor = db.rawQuery("select user_phone,user_name,user_email,user_address from users where user_flag=1", null);
		Log.d("person", "2");
		if (cursor.moveToFirst()) {
			phone = cursor.getString(0);
			name = cursor.getString(1);
			email = cursor.getString(2);
			Log.d("email", email);
			address = cursor.getString(3);
			login.setVisibility(View.INVISIBLE);
			text_login.setVisibility(View.VISIBLE);
			Log.d("person", phone+name+email+address);
			text_phone.setText(phone);
			text_name.setText(name);
		    text_email.setText(email);	
		    text_address.setText(address);
//			if (!address.isEmpty()) {
//					
//			}			
			Log.d("person", "4");
		}else {
			Log.d("person", "5");
		}
		db.close();
	}
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.person_login:
			Intent inte_login = new Intent("android.intent.ACTION_LOGIN");
			startActivity(inte_login);
			finish();
			break;
		case R.id.person_logout:
			db = dbhelper.getWritableDatabase();
			db.execSQL("update users set user_flag=0 where user_flag=1");
			Intent inte_logout = new Intent(PersonActivity.this,homeActivity.class);
			startActivity(inte_logout);
			finish();
			break;
		case R.id.person_text_email:
			Intent inte_email = new Intent(PersonActivity.this,infoChangeActivity.class);
			inte_email.putExtra("flag", "1");
			inte_email.putExtra("phone", text_phone.getText().toString());
			inte_email.putExtra("title", "����");
			inte_email.putExtra("info", text_email.getText().toString());
			startActivity(inte_email);
			finish();
			break;
		case R.id.person_text_name:
			Intent inte_name = new Intent(PersonActivity.this,infoChangeActivity.class);
			inte_name.putExtra("flag", "0");
			inte_name.putExtra("phone", text_phone.getText().toString());
			inte_name.putExtra("title", "����");
			inte_name.putExtra("info", text_name.getText().toString());
			startActivity(inte_name);
			finish();
			break;
		case R.id.person_text_address:
			Intent inte_address = new Intent("android.intent.action.CITY");
			startActivityForResult(inte_address, 3);
			break;
		case R.id.person_pass1:
			Intent inte_pass1 = new Intent(PersonActivity.this,passChangeActivity.class);
			inte_pass1.putExtra("phone", text_phone.getText().toString());
			inte_pass1.putExtra("flag","0");
			inte_pass1.putExtra("title","��½����");
			startActivity(inte_pass1);
			break;
		case R.id.person_pass2:
			Intent inte_pass2 = new Intent(PersonActivity.this,passChangeActivity.class);
			inte_pass2.putExtra("phone", text_phone.getText().toString());
			inte_pass2.putExtra("flag","1");
			inte_pass2.putExtra("title","ȡ������");
			startActivity(inte_pass2);
			break;
		default:
			break;
		}
		
	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode==3&&resultCode==1) {
			final String address = data.getStringExtra("city");
			text_address.setText(address);
			db = dbhelper.getWritableDatabase();
			db.execSQL("update users set user_address=? where user_phone=?",new String[]{address,text_phone.getText().toString()});
			new Thread( new Runnable() {
				public void run() {
					Request request = new Request();
					String url_str = request.root_url+"changeinfo";
					String parameter = "phone="+text_phone.getText().toString()+"&flag=2&info="+address;
					request.initSSLALL(url_str, parameter);
					
				}
			}).start();
		}
	}

}
