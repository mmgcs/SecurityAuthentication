package com.example.login;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import org.json.JSONException;
import org.json.JSONObject;

import com.example.ecdsa.Coder;
import com.example.ecdsa.SM3;
import com.gmm.request.Request;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.AnimationDrawable;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Build.VERSION_CODES;
import android.telephony.TelephonyManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class LoginActivity extends Activity implements OnClickListener {
	private Cursor cursor;
	private SQLiteDatabase db;
	private CreateDataBase dbhelper;
	private Button login,sign,forgetpass;
	private EditText user_phone,user_password;
	private ImageView back,load;
	private NavigationView navigationview;
	private AnimationDrawable ad;
	private Handler handler = new Handler(){
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case 1:
				Log.d("handle","0");
				String result = msg.obj.toString();
				ad.stop();
				load.setVisibility(View.INVISIBLE);
				try {
					JSONObject json = new JSONObject(result);
					String status = json.getString("status");
					Log.d("handle","1");
					
					switch (status) {
					case "0":
						Toast.makeText(LoginActivity.this,"����δע��", Toast.LENGTH_SHORT).show();
						break;
					case "1":
						Toast.makeText(LoginActivity.this,"�û������������", Toast.LENGTH_SHORT).show();
						break;
					case "2":
						String json_phone = json.getString("phone");
						String json_name = json.getString("name");
						String json_token =json.getString("token");
						String json_pubkey = json.getString("pubkey");
						String json_pubkey_sign =json.getString("pubkey_sign");
						String json_encry_prikey =json.getString("encry_prikey");
						String json_address = json.getString("address");
						String json_ca_pubkey = json.getString("ca_pubkey");
						String json_email= json.getString("email");
						String json_first_flag = json.getString("first_flag");
						Log.d("handle","3");
						db = dbhelper.getWritableDatabase();
						cursor = db.rawQuery("select user_phone from users where user_phone=?",new String[]{json_phone});
						if (cursor.moveToFirst()) {
							Log.d("json_email", json_email);
							db.execSQL("update users set user_token=?,user_name=?,user_email=?,user_flag=1 where user_phone=?",new String[]{json_token,json_name,json_email,json_phone});
							Toast.makeText(LoginActivity.this,"�����", Toast.LENGTH_SHORT).show();
							Intent inte_person = new Intent(LoginActivity.this,PersonActivity.class);
							startActivity(inte_person);
							
						}else {
							db.execSQL("insert into users values(?,?,?,?,?,?,?,?,?,?)",new String[]{json_phone,
									json_email,json_name,"1",json_token,json_pubkey,json_pubkey_sign,json_encry_prikey,json_address,json_ca_pubkey});
							Toast.makeText(LoginActivity.this,"�ɹ�", Toast.LENGTH_SHORT).show();
							if (json_first_flag.equals("1")) {
								Intent intent = new Intent(LoginActivity.this,login_firstActivity.class);
								intent.putExtra("phone", json_phone);
								startActivity(intent);
								
								
							}
							
						}
						finish();
						Toast.makeText(LoginActivity.this,"��½�ɹ�", Toast.LENGTH_SHORT).show();
						break;
					case "3":
						Toast.makeText(LoginActivity.this,"�Ƿ��豸", Toast.LENGTH_SHORT).show();
						break;
					default:
						break;
					}
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				break;

			default:
				break;
			}
		};
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		  if (VERSION.SDK_INT >= VERSION_CODES.KITKAT) {
	            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
	            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
	        }

		setContentView(R.layout.login);
		dbhelper = new CreateDataBase(this, "triple.db", null, 1);
		load = (ImageView) findViewById(R.id.login_load);
		ad = (AnimationDrawable) load.getDrawable();
		load.setVisibility(View.INVISIBLE);
		ad.stop();
		login = (Button) findViewById(R.id.login);
		sign = (Button) findViewById(R.id.login_sign);
		user_phone = (EditText) findViewById(R.id.login_phone);
		user_password = (EditText) findViewById(R.id.login_password);
		forgetpass = (Button) findViewById(R.id.login_forgetpassword);
		forgetpass.setOnClickListener(this);
		sign.setOnClickListener(this);
		login.setOnClickListener(this);
		
		user_phone.setFocusable(true);
		user_phone.requestFocus();
		InputMethodManager imm = (InputMethodManager) user_phone.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.toggleSoftInput(0, InputMethodManager.SHOW_FORCED); 

		user_password.setOnFocusChangeListener(new OnFocusChangeListener() {
			
			@Override
			public void onFocusChange(View v, boolean hasFocus) {
				// TODO Auto-generated method stub
				if(hasFocus){
					login.setEnabled(true);
					login.setBackgroundResource(R.drawable.btn_login_1);
				}
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.login_sign:
			Intent intent = new Intent("com.example.login.ACTION_SIGN");
			Log.d("gmm", "sign");
			startActivity(intent);	
			finish();
			break;
		case R.id.login:
			new Thread(new Runnable() {
				public void run() {
					TelephonyManager mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
					String imei = mTelephonyMgr.getDeviceId();
					Log.d("imei", imei);
					Request request = new Request();
					String url_str = request.root_url+"login";
					Log.d("str_url", url_str);
					String parameter;
					try {
						parameter = "phone="+user_phone.getText().toString()+"&pass="+
									URLEncoder.encode(Coder.encryptBASE64(SM3.hash(user_password.getText().toString().getBytes())),"utf-8")+"&imei="+imei;
							String result = request.initSSLALL(url_str, parameter);
							Message msg = new Message();
							msg.what =1;
							msg.obj =result;
							Log.d("handle1",result);
							handler.sendMessage(msg);
					} catch (UnsupportedEncodingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					Log.d("handle","success");
				}
			}).start();
			load.setVisibility(View.VISIBLE);
			ad.start();
			login.setEnabled(false);
			break;
		case R.id.login_forgetpassword:
			Intent inte_forget = new Intent(LoginActivity.this,checkPhoneActivity.class);
			startActivity(inte_forget);
			break;
			
		default:
			break;
		}
		
	}
}
