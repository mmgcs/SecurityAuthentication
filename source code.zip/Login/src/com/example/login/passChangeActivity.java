package com.example.login;

import java.net.URLEncoder;

import org.json.JSONException;
import org.json.JSONObject;

import com.example.ecdsa.Coder;
import com.example.ecdsa.SM3;
import com.gmm.request.Request;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class passChangeActivity extends Activity implements OnClickListener{
	private TextView back,submit,title;
	private EditText passold,passnew;
	private String phone,flag;
	private Handler handler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			if (msg.what==1) {
				try {
					JSONObject json = new JSONObject(msg.obj.toString());
					String status = json.getString("status");
					if (status.equals("1")) {
						Toast.makeText(passChangeActivity.this, "�޸ĳɹ�", Toast.LENGTH_SHORT).show();
						finish();
					}else {
						Toast.makeText(passChangeActivity.this, "ԭ���벻��ȷ", Toast.LENGTH_SHORT).show();
					}
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		};
		
	};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.passchange);
		back = (TextView) findViewById(R.id.changepass_back);
		submit = (TextView) findViewById(R.id.changepass_submit);
		title = (TextView) findViewById(R.id.changepass_title);
		passold = (EditText) findViewById(R.id.changepass_passold);
		passnew = (EditText) findViewById(R.id.changepass_passnew);
		back.setOnClickListener(this);
		submit.setOnClickListener(this);
		Intent intent = getIntent();
		title.setText(intent.getStringExtra("title"));
		phone = intent.getStringExtra("phone");
		flag= intent.getStringExtra("flag");
	}
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.changepass_back:
			finish();
			break;
		case R.id.changepass_submit:
			new Thread(new Runnable() {
				public void run() {
					Request request = new Request();
					String url_str = request.root_url+"changepass";
					String parameter;
					try {
						parameter = "phone="+phone+"&passold="+URLEncoder.encode(Coder.encryptBASE64(SM3.hash(passold.getText().toString().getBytes())),"utf-8")+"&passnew="+
								URLEncoder.encode(Coder.encryptBASE64(SM3.hash(passnew.getText().toString().getBytes())),"utf-8")+"&flag="+flag;
								String result = request.initSSLALL(url_str, parameter);
								Message msg = new Message();
								msg.what=1;
								msg.obj=result;
								handler.sendMessage(msg);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					
				}
			}).start();
			
			
			
			break;

		default:
			break;
		}
		
	}
}

	