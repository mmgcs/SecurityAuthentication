package com.example.login;
import android.view.View.OnClickListener;

import java.net.URLEncoder;

import com.example.ecdsa.Coder;
import com.example.ecdsa.SM3;
import com.gmm.request.Request;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.CompoundButton.OnCheckedChangeListener;
public class setPassActivity extends Activity{
	private String flag ="0";
	private EditText pass1,pass2;
	private CheckBox check1,check2;
	private Button submit;
	private String pass;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.setpass);
		Intent intent = getIntent();
		final String phone =intent.getStringExtra("phone");
		pass="";
		pass1 =(EditText) findViewById(R.id.setpass_1);
		pass2 =(EditText) findViewById(R.id.setpass_2);
		check1 =(CheckBox) findViewById(R.id.setpass_check1);
		check2 = (CheckBox) findViewById(R.id.setpass_check2);
		submit = (Button) findViewById(R.id.setpass_submit);
		check1.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if (isChecked) {
					flag ="1";
					
				}
				
			}
		});
		check2.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if (isChecked) {
					flag ="2";
					
				}
				
			}
		});
		submit.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				new Thread(new Runnable() {
					public void run() {
						Request request = new Request();
						String url_str = request.root_url+"setpass";
						switch (flag) {
						case "1":
							try {
								pass = URLEncoder.encode(Coder.encryptBASE64(SM3.hash(pass1.getText().toString().getBytes())),"utf-8");
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							break;
						case "2":
							try {
								pass = URLEncoder.encode(Coder.encryptBASE64(SM3.hash(pass2.getText().toString().getBytes())),"utf-8");
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							break;

						default:
							break;
						}
						String parameter = "phone="+phone+"&pass="+pass+"&flag="+flag;
						Log.d("parameter", parameter);
						request.initSSLALL(url_str, parameter);	
						
					}
				}).start();
				Toast.makeText(setPassActivity.this, "������", Toast.LENGTH_SHORT).show();
				
				finish();
				
			}
		});
		
	}

}
