package com.example.login;

import com.example.ecdsa.des;
import com.example.ecdsa.ecdsa;
import com.gmm.request.Request;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class homeActivity extends Activity implements OnClickListener{
	ImageView person,daiqu,tuzhong,yiqian,erweima,shouquan;
	ImageView nfc,xiaoge;
	TextView danhao;
	TextView lianxi,jianjie,yunfei,fujin,zhengce;
	Intent inte_express_status = new Intent("android.intent.action.EXPRESS_STATUS");
	ImageView camare,message;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.home);
		
		person = (ImageView) findViewById(R.id.home_person);
		person.setOnClickListener(this);
		danhao = (TextView) findViewById(R.id.home_id);
		daiqu = (ImageView) findViewById(R.id.home_daiqu);
		tuzhong = (ImageView) findViewById(R.id.home_tuzhong);
		yiqian = (ImageView) findViewById(R.id.home_yiqian);
		camare = (ImageView) findViewById(R.id.home_id_camare);
		message =(ImageView) findViewById(R.id.home_message);
		nfc = (ImageView) findViewById(R.id.home_nfc);
		erweima = (ImageView) findViewById(R.id.home_saoma);
		shouquan = (ImageView) findViewById(R.id.home_shouquan);
		lianxi = (TextView) findViewById(R.id.home_connect_us);
		yunfei = (TextView) findViewById(R.id.home_huilv);
		zhengce = (TextView) findViewById(R.id.home_connect_dingdan);
		jianjie = (TextView) findViewById(R.id.home_connect_chanpin);
		fujin = (TextView) findViewById(R.id.home_connect_yingyedian);
		xiaoge = (ImageView) findViewById(R.id.home_xiaoge);
		xiaoge.setOnClickListener(this);
		fujin.setOnClickListener(this);
		jianjie.setOnClickListener(this);
		zhengce.setOnClickListener(this);
		yunfei.setOnClickListener(this);
		lianxi.setOnClickListener(this);
		shouquan.setOnClickListener(this);
		camare.setOnClickListener(this);
		tuzhong.setOnClickListener(this);
		yiqian.setOnClickListener(this);
		danhao.setOnClickListener(this);
		daiqu.setOnClickListener(this);
		message.setOnClickListener(this);
		nfc.setOnClickListener(this);
		erweima.setOnClickListener(this);
		
	}
	
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.home_person:
			Intent inte_person = new Intent("com.example.login.ACTION_PERSON");
			startActivity(inte_person);			
			break;
		case R.id.home_id:
			Log.d("gmm", "dsd");
			Intent inte_danhao = new Intent("android.intent.action.EXPRESS");
			startActivity(inte_danhao);		
			break;
		case R.id.home_daiqu:		
			
			inte_express_status.putExtra("flag", "1");
			startActivity(inte_express_status);
			break;
		case R.id.home_tuzhong:			
			inte_express_status.putExtra("flag","0");
			startActivity(inte_express_status);
			break;
		case R.id.home_yiqian:
			inte_express_status.putExtra("flag","2");
			startActivity(inte_express_status);
			break;
		case R.id.home_id_camare:
			Intent inte_camare = new Intent("android.intent.action.ACTION_SAOMIAO");
			//Intent inte_camare = new Intent("android.intent.action.BARCODETEST");
			startActivity(inte_camare);
			break;
		case R.id.home_saoma:
			inte_express_status.putExtra("flag", "1");
			startActivity(inte_express_status);
			break;
		case R.id.home_nfc:
			inte_express_status.putExtra("flag", "1");
			startActivity(inte_express_status);
			break;
		case R.id.home_shouquan:
			inte_express_status.putExtra("flag", "1");
			startActivity(inte_express_status);
			break;
		case R.id.home_connect_us:
			Intent inte_lianxi = new Intent("android.intent.action.LIANXI" );
			startActivity(inte_lianxi);
			break;
		case R.id.home_huilv:
			Intent inte_yunfei = new Intent("android.intent.action.YUNFEI");
			startActivity(inte_yunfei);
			break;
		case R.id.home_connect_dingdan:
			Intent inte_zhengce = new Intent("android.intent.action.ZHENGCE");
			startActivity(inte_zhengce);
			break;
		case R.id.home_connect_chanpin:
			Intent inte_jianjie = new Intent("android.intent.action.JIANJIE");
			startActivity(inte_jianjie);
			break;
		case R.id.home_connect_yingyedian:
			Intent inte_fujin = new Intent("android.intent.action.FUJIN");
			startActivity(inte_fujin);
			break;
		case R.id.home_xiaoge:
			Intent inte_xiaoge = new Intent("android.intent.action.XIAOGE");
			startActivity(inte_xiaoge);
			break;
		default:
			break;
		}
		
	}
}

	
		
