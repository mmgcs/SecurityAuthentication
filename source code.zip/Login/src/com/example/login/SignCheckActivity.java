package com.example.login;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.json.JSONException;
import org.json.JSONObject;

import com.gmm.request.Request;

import android.R.string;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

public class SignCheckActivity extends Activity {
	protected static final int SHOW_RESPONSE = 0;
	private static final int Gone = 0;
	EditText check;
	Button sign,login;
	RelativeLayout layout;
	ImageView back;
	ImageView option;
	private NavigationView navigationview;
	private Handler handler = new Handler(){
		public void handleMessage(Message msg) {
			switch(msg.what){
			case SHOW_RESPONSE:
				String response = (String) msg.obj;
				JSONObject jsonObj;
				try {
					jsonObj = new JSONObject(response);
					String status = jsonObj.getString("status");
					if(status.equals("1")){
						layout.setVisibility(View.VISIBLE);
						check.setEnabled(false);
					}
					Log.d("check_status", status);
					
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			}
			
		}
	};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.sign_check);
		Intent intent = getIntent();
		final String user_phone = intent.getStringExtra("user_phone");
		sign = (Button) findViewById(R.id.sign_check_button);
		check = (EditText) findViewById(R.id.sign_check_value);		
		layout = (RelativeLayout) findViewById(R.id.layout_sign_check_login);
		navigationview = (NavigationView) findViewById(R.id.sign_check_daohang);
		navigationview.setTitle("��֤");
		back = navigationview.getBackView();
		option = navigationview.getOptionsView();
		option.setVisibility(View.GONE);
		back.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				finish();
				
			}
		});
		login = (Button) findViewById(R.id.btn_sign_check_login);
		login.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent inte_login = new Intent("android.intent.ACTION_LOGIN");
				startActivity(inte_login);
				finish();
				
			}
		});
		
		sign.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				new Thread(new Runnable() {
					public void run() {
						Request request = new Request();
						String url_str = request.root_url+"signcheck";
						String parameter ="phone="+user_phone+"&text="+check.getText().toString();
						String respone = request.initSSLALL(url_str, parameter);
						Log.d("signcheck", respone);
						Message message = new Message();
						message.what = SHOW_RESPONSE;
						message.obj = respone;
						handler.sendMessage(message);
						
					}
				}).start();
			}

			private void Check() {
				// TODO Auto-generated method stub
				new Thread(new Runnable() {
					
					@Override
					public void run() {
						try {
							Log.d("gmm", "have a try");
							GetHttps();
							
						} catch (Exception e) {
							Log.d("gmm", "wrong");
						}
						
					}
					private void GetHttps(){  
				        String https = "https://173.26.102.20/sign/check"; 
				        Log.d("gmm", "have a try1");
				        try{  
				            SSLContext sc = SSLContext.getInstance("TLS");  
				            sc.init(null, new TrustManager[]{(TrustManager) new MyTrustManager()}, new SecureRandom());  
				            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());  
				            HttpsURLConnection.setDefaultHostnameVerifier((HostnameVerifier) new MyHostnameVerifier());  
				            HttpsURLConnection conn = (HttpsURLConnection)new URL(https).openConnection();  
				            conn.setDoOutput(true);  
				            conn.setDoInput(true);  
				            conn.setRequestMethod("POST");
				            conn.connect();	
				            DataOutputStream out = new DataOutputStream(conn.getOutputStream());
				            String post_value = "user_phone="+user_phone+"&check="+check.getText().toString();
				            out.write(post_value.getBytes());
				            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));   
				            StringBuffer sb = new StringBuffer();   
				            String line;  
				            while ((line = br.readLine()) != null)   
				                sb.append(line);                  				            
							Log.d("gmm", sb.toString());  
							Message message = new Message();
							message.what = SHOW_RESPONSE;
							message.obj = sb.toString();
							handler.sendMessage(message);
				           }catch(Exception e){  
				                Log.e(this.getClass().getName(), e.getMessage());  
				           }        
				     }  
				  				  
				      class MyHostnameVerifier implements HostnameVerifier{  
				            @Override  
				            public boolean verify(String hostname, SSLSession session) {  
				                    // TODO Auto-generated method stub  
				                    return true;  
				            }  
				  
				       }  
				  
				       class  MyTrustManager implements X509TrustManager{  
				            @Override  
				            public void checkClientTrusted(X509Certificate[] chain, String authType)  
				                            throws CertificateException {  
				                    // TODO Auto-generated method stub    
				            }  
				            @Override  
				            public void checkServerTrusted(X509Certificate[] chain, String authType)  
				  
				                            throws CertificateException {  
				                    // TODO Auto-generated method stub      
				            }  
				            @Override  
				            public X509Certificate[] getAcceptedIssuers() {  
				                    // TODO Auto-generated method stub  
				                    return null;  
				            }          
				  
				      }     
					
					
					
				}).start();
				
			}
		});
	}

}
