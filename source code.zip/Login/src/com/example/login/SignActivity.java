package com.example.login;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.security.Certificate;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

import org.json.JSONException;
import org.json.JSONObject;

import com.example.ecdsa.Coder;
import com.example.ecdsa.SM3;
import com.example.ecdsa.des;
import com.example.ecdsa.ecdsa;
import com.gmm.request.Request;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class SignActivity extends Activity{
	protected static final int SHOW_RESPONSE = 0;
	Button next;
	EditText user_phone,user_password;
	String phone_value,password_value;
	ImageView back,option;
	String imei,prikey,pubkey,deskey;
	private NavigationView navigationview;
	private CreateDataBase dbHelper;
	private SQLiteDatabase db;
	private Handler handler = new Handler(){
		public void handleMessage(Message msg){
			switch(msg.what){
			case SHOW_RESPONSE:
				String response = (String) msg.obj;
				try {
					JSONObject jsonObj = new JSONObject(response).getJSONObject("result");
					String status = jsonObj.getString("status");
					Log.d("status", status);
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				//Toast.makeText(SignActivity.this, response, Toast.LENGTH_SHORT).show();
			}
			
		}
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.sign);
		next = (Button) findViewById(R.id.sign_next);
		user_phone = (EditText) findViewById(R.id.sign_phone);
		user_password = (EditText) findViewById(R.id.sign_password);
		navigationview = (NavigationView) findViewById(R.id.sign_daohang);
		navigationview.setTitle("ע��");
		option = navigationview.getOptionsView();
		option.setVisibility(View.GONE);
		back = navigationview.getBackView();
		back.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
			}
		});
		TelephonyManager mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		imei = mTelephonyMgr.getDeviceId();
		Log.d("IMEI", imei);//�豸�Ĵ���
		next.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				phone_value = user_phone.getText().toString();
				password_value = user_password.getText().toString();
				try {
					initKey();
				} catch (Exception e) {
					
					e.printStackTrace();
				}
				
				Intent intent = new Intent("com.example.login.ACTION_SIGNCHECK");
				intent.putExtra("user_phone",user_phone.getText().toString());
				startActivity(intent);
				finish();
				
			}

			private void initKey() throws Exception {
				// TODO Auto-generated method stub
				ecdsa Ecdsa = new ecdsa();
				Ecdsa.jdkECDSA();
				prikey = Ecdsa.getPrikey();
				Log.d("prikey", prikey);
				pubkey = Ecdsa.getPubkey();
				Log.d("pubkey", pubkey);
				ecdsa ecd = new ecdsa();
				ecd.jdkECDSA();
				
				des Des = new des();
				deskey = Des.initKey();
				final String encry_prikey = Des.encryptBASE64(Des.encrypt(prikey.getBytes(), deskey));
				Log.d("deskey", deskey);
				String sign = ecd.Sign("123",new String(Des.decrypt(Des.decryptBASE64(encry_prikey), deskey)));
				Log.d("test_sign_des", sign);
				boolean result = ecd.SignCheck("123", sign, pubkey);
				Log.d("test_result_des", result+"");
				new Thread( new Runnable() {
					public void run() {
						Request request = new Request();
						String url = request.root_url+"sign";
						String parameter;
						try {
							parameter = "phone="+user_phone.getText().toString()+"&password="
									+URLEncoder.encode(Coder.encryptBASE64(SM3.hash(user_password.getText().toString().getBytes())),"utf-8")
											+"&imei="+imei+"&pubkey="+URLEncoder.encode(pubkey,"utf-8")
									+"&encry_prikey="+URLEncoder.encode(encry_prikey,"utf-8")+"&des_key="+URLEncoder.encode(deskey,"utf-8");
							Log.d("parameter", parameter);
							String result = request.initSSLALL(url, parameter);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
						
						
						
						
					}
				}).start();

			
			}
		});
		
	}

}
