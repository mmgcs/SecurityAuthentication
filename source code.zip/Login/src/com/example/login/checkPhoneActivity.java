package com.example.login;

import org.json.JSONObject;

import com.gmm.request.Request;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class checkPhoneActivity extends Activity implements OnClickListener{
	private EditText phone,text;
	private Button send;
	private TextView submit;
	private Handler handler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			String result = msg.obj.toString();
			try {
				JSONObject json = new JSONObject(result);
				String question = json.getString("question");
				if (!question.equals("0")) {
					Intent inte_question = new Intent(checkPhoneActivity.this,checkQuestionActivity.class);
					inte_question.putExtra("phone", phone.getText().toString());
					inte_question.putExtra("question", question);
					startActivity(inte_question);
					finish();
				}else {
					Toast.makeText(checkPhoneActivity.this, "��֤����", Toast.LENGTH_SHORT);
				}
			} catch (Exception e) {
				// TODO: handle exception
			}
			
		};
	};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.passforget);
		phone = (EditText) findViewById(R.id.passforget_phone);
		text = (EditText) findViewById(R.id.passforget_text);
		send =(Button) findViewById(R.id.passforget_phone_send);
		submit =(TextView) findViewById(R.id.passforget_submit);
		send.setOnClickListener(this);
		submit.setOnClickListener(this);
		
	}
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.passforget_phone_send:
			new Thread(new Runnable() {
				public void run() {
					Request request = new Request();
					String url_str = request.root_url+"sendtext";
					String parameter = "phone="+phone.getText().toString();
					request.initSSLALL(url_str, parameter);	
				}
			}).start();
			Toast.makeText(checkPhoneActivity.this, "�ѷ���", Toast.LENGTH_SHORT).show();
			break;
		case R.id.passforget_submit:
			new Thread(new Runnable() {
				public void run() {
					Request request = new Request();
					String url_str = request.root_url+"textcheck";
					String parameter = "phone="+phone.getText().toString()+"&text="+text.getText().toString();
					String result = request.initSSLALL(url_str, parameter);
					Log.d("result", result);
					Message msg = new Message();
					msg.obj = result;
					handler.sendMessage(msg);
					
				}
			}).start();
			break;

		default:
			break;
		}
		
	}

}
