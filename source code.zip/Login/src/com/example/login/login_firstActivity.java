package com.example.login;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import com.example.ecdsa.Coder;
import com.example.ecdsa.SM3;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;

public class login_firstActivity extends Activity{
	private Button next;
	private EditText password2;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		final String phone;
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.login_first_password);
		Intent intent = getIntent();
		phone = intent.getStringExtra("phone");
		next = (Button) findViewById(R.id.login_first_next);
		password2 = (EditText) findViewById(R.id.login_first_password);
		next.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				Intent inte_login_first2 = new Intent(login_firstActivity.this,login_firstActivity2.class);
				try {
					inte_login_first2.putExtra("password2", URLEncoder.encode(Coder.encryptBASE64(SM3.hash(password2.getText().toString().getBytes())),"utf-8"));
					inte_login_first2.putExtra("phone", phone);
					startActivity(inte_login_first2);
					finish();
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			}
		});
	}

}
