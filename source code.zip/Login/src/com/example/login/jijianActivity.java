package com.example.login;

import java.util.ArrayList;

import com.ericssonlabs.erweimaActivity;
import com.gmm.request.myxiaogeActivity;
import com.gmm.request.personTest;
import com.gmm.request.selectxiaogeActivity;
import com.mrwujay.cascade.activity.cityActivity;

import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

public class jijianActivity extends Activity implements OnClickListener{
	private EditText shou_name,shou_phone,shou_addr,shou_addr_info,
	ji_name,ji_phone,ji_addr,ji_addr_info,
	personid,info;
	private CreateDataBase dbhelper;
	private SQLiteDatabase db;
	private CheckBox box1,box2;
	private Button btn_submit;
	private String id_temp="";
	private personTest pt;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.jijian);
		shou_addr = (EditText) findViewById(R.id.jijian_shou_address);
		
		ji_addr = (EditText) findViewById(R.id.jijian_ji_address);
		box1 = (CheckBox) findViewById(R.id.xiaoge_jijian_phoneprotect);
		box2 =(CheckBox) findViewById(R.id.xiaoge_jijian_idprotect);
		personid = (EditText) findViewById(R.id.xiaoge_jijian_id);
		ji_name = (EditText) findViewById(R.id.jijian_ji_name);
		ji_phone =(EditText)findViewById(R.id.jijian_ji_phone);
		ji_addr = (EditText)findViewById(R.id.jijian_ji_address);
		ji_addr_info = (EditText)findViewById(R.id.jijian_ji_address_info);
		info =(EditText)findViewById(R.id.jijian_info);
		shou_name = (EditText)findViewById(R.id.jijian_shou_name);
		shou_phone = (EditText)findViewById(R.id.jijian_shou_phone);
		shou_addr = (EditText)findViewById(R.id.jijian_shou_address);
		shou_addr_info =(EditText)findViewById(R.id.jijian_shou_address_info);
		btn_submit = (Button) findViewById(R.id.xiaoge_btn_submit);
		dbhelper = new CreateDataBase(this, "triple.db", null, 1);
		db = dbhelper.getWritableDatabase();
		pt =new personTest(db);
		Log.d("phone", pt.getphone());
		btn_submit.setOnClickListener(this);
		box2.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if (isChecked) {
					personid.setVisibility(View.VISIBLE);
					
				}else {
					personid.setVisibility(View.INVISIBLE);
					personid.setText("");
				}
				
			}
		});
		shou_addr.setOnFocusChangeListener(new OnFocusChangeListener() {
			
			@Override
			public void onFocusChange(View v, boolean hasFocus) {
				if (hasFocus) {
					Intent inte_shou_addr = new Intent("android.intent.action.CITY");
					startActivityForResult(inte_shou_addr, 2);
				}
				
			}
		});
		ji_addr.setOnFocusChangeListener(new OnFocusChangeListener() {
			
			@Override
			public void onFocusChange(View v, boolean hasFocus) {
				if (hasFocus) {
					Intent inte_ji_addr = new Intent("android.intent.action.CITY");
					startActivityForResult(inte_ji_addr, 1);
				
				}
			}
		});
		initInfo_ji();
		
	}
	private void initInfo_ji() {
		
		String phone = pt.getphone();
		String name =pt.getName();
		String city = pt.getCity();
		ji_phone.setText(phone);
		ji_name.setText(name);
		ji_addr.setText(city);
		
		
	}
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.xiaoge_btn_submit:
			Intent intent = getIntent();
			String online = intent.getStringExtra("online");
			if (online.equals("1")) {
				Intent inte_select = new Intent(jijianActivity.this,selectxiaogeActivity.class);
				inte_select.putExtra("shou_name", shou_name.getText().toString());
				inte_select.putExtra("shou_phone", shou_phone.getText().toString());
				inte_select.putExtra("shou_addr", shou_addr.getText().toString());
				inte_select.putExtra("shou_addr_info", shou_addr_info.getText().toString());
				inte_select.putExtra("ji_name",ji_name.getText().toString());
				inte_select.putExtra("ji_phone", ji_phone.getText().toString());
				inte_select.putExtra("ji_addr", ji_addr.getText().toString());
				inte_select.putExtra("ji_addr_info", ji_addr_info.getText().toString());
				inte_select.putExtra("info",info.getText().toString());
				inte_select.putExtra("personid", personid.getText().toString());
				startActivity(inte_select);
				
			}else {
				Intent inte_erweima = new Intent(jijianActivity.this,erweimaActivity.class);
				com.alibaba.fastjson.JSONObject json1 = new com.alibaba.fastjson.JSONObject();
				json1.put("shou_name", shou_name.getText().toString());
				json1.put("shou_phone", shou_phone.getText().toString());
				json1.put("shou_addr", shou_addr.getText().toString());
				json1.put("shou_addr_info", shou_addr_info.getText().toString());
				json1.put("ji_name",ji_name.getText().toString());
				json1.put("ji_phone", ji_phone.getText().toString());
				json1.put("ji_addr", ji_addr.getText().toString());
				json1.put("ji_addr_info", ji_addr_info.getText().toString());
				json1.put("info",info.getText().toString());
				json1.put("personid",personid.getText().toString());
				String data = json1.toJSONString();
				inte_erweima.putExtra("password", data);
				startActivity(inte_erweima);
			}
		

		default:
			break;
		}
		
	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		if(requestCode==1 && resultCode==1){
			String ji_addr_result = data.getExtras().getString("city");
			ji_addr.setText(ji_addr_result);
		}else if (requestCode == 2 && resultCode ==1) {
			String shou_addr_result = data.getExtras().getString("city");
			shou_addr.setText(shou_addr_result);
			
		}
	}

}
