package com.example.login;

import java.util.ArrayList;
import java.util.HashMap;

import com.gmm.request.myxiaogeActivity;
import com.gmm.request.orderstatusActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

public class xiaogeActivity extends Activity implements OnClickListener{
	private ListView list;
	private SimpleAdapter mSimpleAdapter;	
	private ArrayList<HashMap<String, Object>> listItem = new ArrayList<HashMap<String,Object>>();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.xiaoge);
		list = (ListView) findViewById(R.id.xiaoge_home_list);		
		
		HashMap<String, Object> map;
		map = new HashMap<String, Object>();
		map.put("ic_xiaoge_img", R.drawable.ic_xiaoge_shangmen);
		map.put("ic_xiaoge_text","����ԤԼ");
		listItem.add(map);
		map = new HashMap<String, Object>();
		map.put("ic_xiaoge_img", R.drawable.ic_xiaoge_dangmian);
		map.put("ic_xiaoge_text","�����");
		listItem.add(map);
		map = new HashMap<String, Object>();
		map.put("ic_xiaoge_img", R.drawable.ic_xiaoge_dingdan);
		map.put("ic_xiaoge_text","����״̬");
		listItem.add(map);
		map = new HashMap<String, Object>();
		map.put("ic_xiaoge_img", R.drawable.ic_xiaoge_xiaoge);
		map.put("ic_xiaoge_text","���С��");
		listItem.add(map);
		mSimpleAdapter = new SimpleAdapter(xiaogeActivity.this, listItem,R.layout.item_xiaoge,new String[]{"ic_xiaoge_img","ic_xiaoge_text"}, new int[]{R.id.item_xiaoge_img,R.id.item_xiaoge_text});
		list.setAdapter(mSimpleAdapter);
		list.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				Intent inte_jijian = new Intent(xiaogeActivity.this,jijianActivity.class);
				switch (position) {
				case 0:					
					inte_jijian.putExtra("online", "1");
					startActivity(inte_jijian);					
					break;
				case 1:
					inte_jijian.putExtra("online", "0");
					startActivity(inte_jijian);					
					break;
				case 2:
					Intent inte_order_status = new Intent(xiaogeActivity.this,orderstatusActivity.class);
					startActivity(inte_order_status);			
					break;
				case 3:
					Intent inte_myxiao = new Intent(xiaogeActivity.this,myxiaogeActivity.class);
					startActivity(inte_myxiao);
					break;

				default:
					break;
				}
				
			}
			
		});
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
	}

}
