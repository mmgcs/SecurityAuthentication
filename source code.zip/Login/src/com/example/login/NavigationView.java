package com.example.login;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;

public class NavigationView extends RelativeLayout{
	private ImageView back_view,options_view;
	private TextView  title;
	public NavigationView(Context context,AttributeSet attrs) {
		super(context,attrs);
		// TODO Auto-generated constructor stub
		View view = LayoutInflater.from(context).inflate(R.layout.daohang, this, true);
		back_view = (ImageView) findViewById(R.id.back);
		options_view = (ImageView) findViewById(R.id.options);
		title = (TextView) findViewById(R.id.title);
	}
	public TextView getTitleView(){
		return title;
	}
	public void setTitle(String Title){
		title.setText(Title);
	}
	public ImageView getBackView(){
		return back_view;
	}
	public ImageView getOptionsView(){
		return options_view;
	}
	

	
	
}
