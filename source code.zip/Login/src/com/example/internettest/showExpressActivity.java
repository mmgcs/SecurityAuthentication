package com.example.internettest;

import java.io.BufferedReader;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.ecdsa.Coder;
import com.example.ecdsa.SM3;
import com.example.ecdsa.ecdsa;
import com.example.login.CreateDataBase;
import com.example.login.R;
import com.gmm.request.Request;
import com.gmm.request.personTest;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
public class showExpressActivity extends Activity implements OnClickListener{
	private Button qujian,add,qujian1,qujian2;
	private TextView textid,textname;
	private ListView lv;
	private String company,id,status;
	private SimpleAdapter mSimpleAdapter;
	private CreateDataBase dbhelper;
	private SQLiteDatabase db;
	private Cursor cursor;
	private ImageView load;
	private AnimationDrawable ad;
	private HashMap<String,String> Map1 = new HashMap<String,String>();	
	private personTest pt;
	private String way_flag;

	private RelativeLayout sign_layout;
	private EditText sign_password;
	private Button sign_password_submit;
	public ArrayList<HashMap<String, Object>> listItem = new ArrayList<HashMap<String,Object>>();
	@SuppressLint("HandlerLeak")
	private Handler handler = new Handler(){
		public void handleMessage(Message msg){
			String response;
			switch (msg.what){
			case 0:
				response = (String)msg.obj;
				Log.d("gmmt", response);
				setJson(response);
				Log.d("gmmt", listItem.toString());
				mSimpleAdapter = new SimpleAdapter(showExpressActivity.this, listItem, R.layout.item,
						new String[]{"time", "action"},new int[]{R.id.item_express_time,R.id.item_express_action});
				
				try {
					ad.stop();
					load.setVisibility(View.GONE);
					lv.setAdapter(mSimpleAdapter);
				} catch (Exception e) {
					Log.d("gmmerror", e.toString());
				}
				break;
			case 1://ȡ��
				Log.d("qujian", msg.obj.toString());
				try {
					
					JSONObject json =new JSONObject(msg.obj.toString());
					String des_key =json.getString("des_key");
					String random = json.getString("random");
					String flag = json.getString("flag");
					String phone = pt.getphone();
					String sign =pt.getSign(phone+id, des_key);
					String pub = pt.getPub();
					Log.d("pub", pub);
					switch (flag) {
					case "0":
						Intent inte_nfc = new Intent("android.intent.action.NFC");
						inte_nfc.putExtra("id", id);
						inte_nfc.putExtra("phone", phone);
						inte_nfc.putExtra("password",random);
						inte_nfc.putExtra("sign", sign);
						inte_nfc.putExtra("pub", pub);
						startActivity(inte_nfc);
						break;
					case "1":
						Intent inte_erweima = new Intent("android.intent.action.BARCODETEST");
						com.alibaba.fastjson.JSONObject json1 = new com.alibaba.fastjson.JSONObject();
						json1.put("phone", phone);
						json1.put("id",id);
						json1.put("password",random);
						json1.put("flag","0");
						json1.put("pub", pub);
						json1.put("sign", sign);
						String data = json1.toJSONString();
						Log.d("erweima",data);
						ecdsa Ecdsa = new ecdsa();
						Ecdsa.jdkECDSA();
						boolean gmm = Ecdsa.SignCheck(phone+id,sign, pub);
						Log.d("show1", phone+id);
						Log.d("show2", sign);
						Log.d("show3", pub);
						Log.d("dsdf", gmm+"");
						try {
							inte_erweima.putExtra("password", Coder.encryptBASE64(data.getBytes()));
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						inte_erweima.putExtra("flag","0");
						startActivity(inte_erweima);
						
						break;
					case "2":
						Intent inte_erweima1 = new Intent("android.intent.action.BARCODETEST");
						com.alibaba.fastjson.JSONObject json2 = new com.alibaba.fastjson.JSONObject();
						json2.put("phone", phone);
						json2.put("id", id);
						json2.put("password", random);
						json2.put("flag", "1");
						json2.put("pub", pub);
						json2.put("sign", sign);
						String data1 = json2.toJSONString();
						Log.d("erweima",data1);
						try {
							inte_erweima1.putExtra("password",  Coder.encryptBASE64(data1.getBytes()));
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						inte_erweima1.putExtra("flag","1");
						startActivity(inte_erweima1);
						break;

					default:
						break;
					}
					
					
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				break;
			case 2:
				try {
					JSONObject json_sign = new JSONObject(msg.obj.toString());
					String status = json_sign.getString("status");
					if (status.equals("1")) {
						switch (way_flag) {
						case "0":
							qujian();
							sign_layout.setVisibility(View.INVISIBLE);
							break;
						case "1":
							qujian1();
							sign_layout.setVisibility(View.INVISIBLE);
							break;
						case "2":
							qujian2();
							sign_layout.setVisibility(View.INVISIBLE);
							break;

						default:
							break;
						}
					}else {
						Toast.makeText(showExpressActivity.this, "�������", Toast.LENGTH_SHORT).show();
						sign_layout.setVisibility(View.VISIBLE);
					}
				} catch (Exception e) {
					// TODO: handle exception
				}
				break;
			default:
				break;
				
				
			}
		}
		private void setJson(String response) {
			try {		
				JSONArray arraylist = new JSONObject(response).getJSONArray("result");
				for(int i = arraylist.length()-1; i >-1; i--){
					HashMap<String, Object> map = new HashMap<String, Object>();
					JSONObject reobj = (JSONObject) arraylist.get(i);
					String action = reobj.getString("action");
					String time = reobj.getString("time");
					
					map.put("action", action);
					map.put("time", time);
					listItem.add(map);
				}
			} catch (Exception e) {
				e.printStackTrace();// TODO: handle exception
			}
			// TODO Auto-generated method stub
			
		}
	};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.show_express);
		
		load = (ImageView) findViewById(R.id.show_load);
		ad = (AnimationDrawable) load.getDrawable();
		ad.start();
	
		initMap1();
		lv = (ListView) findViewById(R.id.show_express_list);
	    qujian = (Button) findViewById(R.id.show_express_qujian);
	    qujian1 = (Button) findViewById(R.id.show_express_qujian1);
	    qujian2 = (Button) findViewById(R.id.show_express_qujian2);
	    add = (Button) findViewById(R.id.show_express_add);
	    add.setVisibility(View.GONE);
	    textid = (TextView) findViewById(R.id.show_express_id1);
	    textname =(TextView) findViewById(R.id.show_express_name1);
	    sign_layout =(RelativeLayout) findViewById(R.id.sign_password_layout);
	    sign_layout.setVisibility(View.INVISIBLE);
	    sign_password =(EditText) findViewById(R.id.sign_password_pass);
	    sign_password_submit = (Button) findViewById(R.id.sign_password_btn);
	    sign_password_submit.setOnClickListener(this);
	    add.setOnClickListener(this);
	    qujian.setOnClickListener(this);
	    qujian1.setOnClickListener(this);
	    qujian2.setOnClickListener(this);
		Intent intent = getIntent();
		company = intent.getStringExtra("company");
		id = intent.getStringExtra("id");
		//Log.d("id1", id);
		status = intent.getStringExtra("status");	
		dbhelper = new CreateDataBase(this, "triple.db", null, 1);
		db = dbhelper.getWritableDatabase();
		pt = new personTest(db);
		switch (status) {
		case "0":
			
			qujian.setVisibility(View.GONE);
			qujian1.setVisibility(View.GONE);
			qujian2.setVisibility(View.GONE);
			break;
		case "1":
			//qujian.setVisibility(View.GONE);
			add.setVisibility(View.GONE);
			break;
		case "2":
			qujian.setVisibility(View.GONE);
			qujian1.setVisibility(View.GONE);
			qujian2.setVisibility(View.GONE);
			add.setVisibility(View.GONE);
			break;
		default:
			break;
		}
		textid.setText(id);
		textname.setText(Map1.get(company));
		Log.d("gmm", company);
		Log.d("gmm", id);
		sendRequest();
		Log.d("gmm","sendrequest");
	}
	

	private void initMap1() {
		Map1.put("shunfeng", "˳������");
		Map1.put("zhongtong", "��ͨ���");
		Map1.put("shentong", "��ͨ���");
		Map1.put("yuantong", "Բͨ���");
		Map1.put("yunda", "�ϴ���");
		Map1.put("huitongkuaidi", "������ͨ");
		Map1.put("ems", "EMS");
		Map1.put("tiantian", "������");
		Map1.put("quanfengkuaidi", "ȫ����");
		
		
	}

	private void sendRequest() {
		//Log.d("gmm", "Jinrule");
		new Thread(new Runnable() {			
			@Override
			public void run() {
				HttpURLConnection connection = null;
				try{
					String url_s ="http://api.avatardata.cn/ExpressNumber/Lookup?key=a40e0a8794d24938837ef2e261cd690d&company="+company+"&id="
					+id;
					//Log.d("gmm_url", url_s);
					URL url = new URL(url_s);
					connection = (HttpURLConnection) url.openConnection();
					connection.setRequestMethod("GET");
					InputStream in = connection.getInputStream();
					BufferedReader reader = new BufferedReader(new InputStreamReader(in));
					StringBuilder response = new StringBuilder();
					String line;
					while ((line = reader.readLine()) != null){
						response.append(line);
					}
					Message message = new Message();
					message.what = 0;
					message.obj = response.toString();
					//Log.d("gmm", response.toString());
					handler.sendMessage(message);
				}catch(Exception e){
					e.printStackTrace();
				}finally{
					if(connection != null){
						connection.disconnect();
					}
				}
								
			}
		}).start();
		
	}


	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.show_express_add:
		    new Thread( new Runnable() {
                public void run() {
                    Request request = new Request();
                    String url = request.root_url+"addexpress";
                    String parameter;
                    try {
                        parameter = "id="+id+"&company="
                                +company+"&recive="+pt.getphone()+"&flag=0";
                        Log.d("parameter", parameter);
                        String result = request.initSSLALL(url, parameter);
                        Log.d("add_result", result);
                    } catch (Exception e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }                  
                }
            }).start();
		    Toast.makeText(showExpressActivity.this, "���ӳɹ�", Toast.LENGTH_SHORT).show();
            add.setVisibility(View.GONE);
//			try {
////				db.execSQL("insert into express values(?,?,?,?,?)",new String[]{id,"","","0",company});
//				Toast.makeText(showExpressActivity.this, "���ӳɹ�", Toast.LENGTH_SHORT).show();
//				add.setVisibility(View.GONE);
//			} catch (Exception e) {
//				// TODO: handle exception
//				Toast.makeText(showExpressActivity.this, "��������", Toast.LENGTH_SHORT).show();
//				add.setVisibility(View.GONE);
//			}
			break;
		case R.id.show_express_qujian:
		    sign_password.setText("");
			sign_layout.setVisibility(View.VISIBLE);
			way_flag="0";
			//qujian();
			break;
		case R.id.show_express_qujian1:
		    sign_password.setText("");
			sign_layout.setVisibility(View.VISIBLE);
			way_flag="1";
			//qujian1();
			break;
		case R.id.show_express_qujian2:
		    sign_password.setText("");
			sign_layout.setVisibility(View.VISIBLE);
			way_flag="2";
			//qujian2();
			break;
		case R.id.sign_password_btn:
			checkSignpass();
			break;
		default:
			break;
		}
		
	}


	private void checkSignpass() {
		new Thread( new Runnable() {
			public void run() {
				Request request = new Request();
				String url_str = request.root_url+"checksignpass";
				String parameter;
				try {
					parameter = "phone="+pt.getphone()+"&signpass="+URLEncoder.encode(Coder.encryptBASE64(SM3.hash(sign_password.getText().toString().getBytes())),"utf-8");
					String result = request.initSSLALL(url_str, parameter);
					
					Message msg= new Message();
					msg.what =2;
					msg.obj = result;
					handler.sendMessage(msg);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				
			}
		}).start();
		
	}


	private void qujian() {
		new Thread( new Runnable() {
			public void run() {
				Request request = new Request();
				String url_str = request.root_url+"qujian";
				String parameter = "phone="+pt.getphone()+"&flag=0";
				String result = request.initSSLALL(url_str, parameter);
				Message msg= new Message();
				msg.what =1;
				msg.obj = result;
				handler.sendMessage(msg);
				
				
			}
		}).start();
		
	}


	private void qujian1() {
		new Thread(new Runnable() {
			public void run() {
				Request request1 = new Request();
				String url_str1 = request1.root_url+"qujian";
				String parameter1 = "phone="+pt.getphone()+"&flag=1";
				String result1 = request1.initSSLALL(url_str1, parameter1);
				Message msg1= new Message();
				msg1.what =1;
				msg1.obj = result1;
				Log.d("sdfdf", result1);
				handler.sendMessage(msg1);
			}
		}).start();
		
	}


	private void qujian2() {
		new Thread(new Runnable() {
			public void run() {
				Request request2 = new Request();
				String url_str2 = request2.root_url+"qujian";
				String parameter2 = "phone="+pt.getphone()+"&flag=2";
				String result2 = request2.initSSLALL(url_str2, parameter2);
				Message msg2= new Message();
				msg2.what =1;
				msg2.obj = result2;
				handler.sendMessage(msg2);
			}
		}).start();
		
	}
}

