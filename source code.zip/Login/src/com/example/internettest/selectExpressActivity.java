package com.example.internettest;

import java.util.ArrayList;
import java.util.HashMap;
import com.example.login.R;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.SimpleAdapter;

public class selectExpressActivity extends Activity{
	private ListView list_express;
	private ArrayList<HashMap<String,Object>> listItem;	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.select_express);
		list_express = (ListView) findViewById(R.id.list_express);/*����һ����̬����*/   	
		listItem = new ArrayList<HashMap<String,Object>>();/*�������д������*/
		HashMap<String, Object> map = new HashMap<String, Object>();  
        map.put("express_image", R.drawable.shunfeng);//����ͼƬ            map.put("ItemTitle", "��"+i+"��");  
        map.put("express_name", "˳����");  
        listItem.add(map);
        
        map = new HashMap<String, Object>();  
        map.put("express_image", R.drawable.zhongtong);//����ͼƬ            map.put("ItemTitle", "��"+i+"��");  
        map.put("express_name", "��ͨ���");
        listItem.add(map);
        
        map = new HashMap<String, Object>();  
        map.put("express_image", R.drawable.shentong);//����ͼƬ            map.put("ItemTitle", "��"+i+"��");  
        map.put("express_name", "��ͨ���");
        listItem.add(map);
        
        map = new HashMap<String, Object>();  
        map.put("express_image", R.drawable.yuantong);//����ͼƬ            map.put("ItemTitle", "��"+i+"��");  
        map.put("express_name", "Բͨ���");
        listItem.add(map);
        
        map = new HashMap<String, Object>();  
        map.put("express_image", R.drawable.yunda);//����ͼƬ            map.put("ItemTitle", "��"+i+"��");  
        map.put("express_name", "�ϴ���");
        listItem.add(map);
        
        map = new HashMap<String, Object>();  
        map.put("express_image", R.drawable.baishihuitong);//����ͼƬ            map.put("ItemTitle", "��"+i+"��");  
        map.put("express_name", "������ͨ");
        listItem.add(map);
        
        map = new HashMap<String, Object>();  
        map.put("express_image", R.drawable.ems);//����ͼƬ            map.put("ItemTitle", "��"+i+"��");  
        map.put("express_name", "EMS");
        listItem.add(map);
        
        map = new HashMap<String, Object>();  
        map.put("express_image", R.drawable.tiantian);//����ͼƬ            map.put("ItemTitle", "��"+i+"��");  
        map.put("express_name", "������");
        listItem.add(map);
        
        map = new HashMap<String, Object>();  
        map.put("express_image", R.drawable.quanfeng);//����ͼƬ            map.put("ItemTitle", "��"+i+"��");  
        map.put("express_name", "ȫ����");
        listItem.add(map);
        
        
        SimpleAdapter mSimpleAdapter = new SimpleAdapter(this, listItem, R.layout.item_express,
				new String[]{"express_image", "express_name"},new int[]{R.id.express_image,R.id.express_name});
		Log.d("gmm", "4");
		try {
			list_express.setAdapter(mSimpleAdapter);
		} catch (Exception e) {
			Log.d("gmmerror", e.toString());
		}
		list_express.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				// TODO Auto-generated method stub
				Intent intent = new Intent();
				intent.putExtra("express_id",""+position);
				Log.d("qw1", ""+position);
				setResult(RESULT_OK, intent);
				finish();
				
			}
		});
	}

}
