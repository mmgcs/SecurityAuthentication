package com.example.internettest;
import com.example.login.R;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.JSONArray;
import org.json.JSONObject;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
public class expressActivity extends Activity implements OnClickListener{
	public static final int SHOW_RESPONSE = 0;
	public String response;
	private Button button;
	private TextView express;
	private EditText edittext;
	private ListView lv;
	private SimpleAdapter mSimpleAdapter;
	private String company = "shunfeng";
	public ArrayList<HashMap<String, Object>> listItem = new ArrayList<HashMap<String,Object>>();


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.express_main);
		button = (Button) findViewById(R.id.button);
		edittext = (EditText) findViewById(R.id.edittext);
		express =  (TextView) findViewById(R.id.express_main_express);
		try {
			Intent intent = getIntent();
			String id = intent.getStringExtra("id");
			edittext.setText(id);
		} catch (Exception e) {
			// TODO: handle exception
		}
		button.setOnClickListener(this);
		express.setOnClickListener(this);
					
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.button:
			Intent inte_showexpress = new Intent("android.intent.action.SHOWEXPRESS" );
			inte_showexpress.putExtra("company", company);
			inte_showexpress.putExtra("id", edittext.getText().toString());
			inte_showexpress.putExtra("status", "0");
			startActivity(inte_showexpress);
			finish();
			break;
		case R.id.express_main_express:
			Log.d("gmm", "xx");
			Intent intent = new Intent(expressActivity.this,selectExpressActivity.class);
			startActivityForResult(intent, 1);
			Log.d("gmm", "xxxx");

		default:
			break;
		}
		
		
	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		switch (requestCode) {
		case 1:
			if(resultCode == RESULT_OK){
				String express_id = data.getStringExtra("express_id");
				switch (express_id){
				case "0":
					express.setText("˳����");
					company = "shunfeng";
					break;
				case "1":
					express.setText("��ͨ���");
					company = "zhongtong";
					break;
				case "2":
					express.setText("��ͨ���");
					company = "shentong";
					break;
				case "3":
					express.setText("Բͨ���");
					company = "yuantong";
					break;
				case "4":
					express.setText("�ϴ���");
					company = "yunda";
					break;
				case "5":
					express.setText("������ͨ");
					company = "huitongkuaidi";
					break;
				case "6":
					express.setText("EMS");
					company = "ems";
					break;
				case "7":
					express.setText("������");
					company = "tiantian";
					break;
				case "8":
					express.setText("ȫ����");
					company = "quanfengkuaidi";
					break;
				
				default:
					break;
				}
				
			}
			break;

		default:
			break;
		}
	}


}